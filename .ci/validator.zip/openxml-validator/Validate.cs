using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Validation;
using DocumentFormat.OpenXml.Wordprocessing;
using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml.Presentation;

enum ParseModes
{
    DOCX,
    XLSX,
    PPTX
}

class Program
{
    static void Main(string[] args)
    {
        ParseModes pm = ParseModes.DOCX;
        if (args.Length < 1)
        {
            Console.WriteLine("Please provide an input files/flags as argument");
            return;
        }
        int startIndex = 0;
        switch (args[0])
        {
            case "--docx":
                pm = ParseModes.DOCX;
                startIndex++;
                break;
            case "--xlsx":
                pm = ParseModes.XLSX;
                startIndex++;
                break;
            case "--pptx":
                pm = ParseModes.PPTX;
                startIndex++;
                break;
        }

        for (int i = startIndex; i < args.Length; i++)
        {
            Console.WriteLine("Processing: {0}", args[i]);

            if (pm == ParseModes.DOCX)
            {
                Console.WriteLine("DOCX File: {0}", args[i]);
                using (WordprocessingDocument wordDoc =
                    WordprocessingDocument.Open(args[i], false))
                {
                    OpenXmlValidator validator = new OpenXmlValidator(DocumentFormat.OpenXml.FileFormatVersions.Office2021);

                    var errors = validator.Validate(wordDoc);
                    if (errors.Count() == 0)
                        Console.WriteLine("Document is valid");
                    else
                        Console.WriteLine("Document is not valid");
                    Console.WriteLine();
                    foreach (var error in errors)
                    {
                        Console.WriteLine("Error description: {0}", error.Description);
                        Console.WriteLine("Content type of part with error: {0}",
                            error.Part.ContentType);
                        Console.WriteLine("Location of error: {0}", error.Path.XPath);
                    }
                }
            }
            else if (pm == ParseModes.XLSX)
            {
                Console.WriteLine("XLSX File: {0}", args[i]);
                using (SpreadsheetDocument excelDoc =
                    SpreadsheetDocument.Open(args[i], false))
                {
                    OpenXmlValidator validator = new OpenXmlValidator(DocumentFormat.OpenXml.FileFormatVersions.Office2021);

                    var errors = validator.Validate(excelDoc);
                    if (errors.Count() == 0)
                        Console.WriteLine("Document is valid");
                    else
                        Console.WriteLine("Document is not valid");
                    Console.WriteLine();
                    foreach (var error in errors)
                    {
                        Console.WriteLine("Error description: {0}", error.Description);
                        Console.WriteLine("Content type of part with error: {0}",
                            error.Part.ContentType);
                        Console.WriteLine("Location of error: {0}", error.Path.XPath);
                    }
                }
            }
            else if (pm == ParseModes.PPTX)
            {
                Console.WriteLine("PPTX File: {0}", args[i]);
                using (PresentationDocument pptDoc =
                    PresentationDocument.Open(args[i], false))
                {
                    OpenXmlValidator validator = new OpenXmlValidator(DocumentFormat.OpenXml.FileFormatVersions.Office2021);

                    var errors = validator.Validate(pptDoc);
                    if (errors.Count() == 0)
                        Console.WriteLine("Document is valid");
                    else
                        Console.WriteLine("Document is not valid");
                    Console.WriteLine();
                    foreach (var error in errors)
                    {
                        Console.WriteLine("Error description: {0}", error.Description);
                        Console.WriteLine("Content type of part with error: {0}",
                            error.Part.ContentType);
                        Console.WriteLine("Location of error: {0}", error.Path.XPath);
                    }
                }
            }
        }
    }
}
